// --------------------------------------
// Requerimiento de librerías
// --------------------------------------
const { Sequelize } = require('sequelize');

// --------------------------------------
// Configuración de conexión a MySQL
// --------------------------------------
const sequelize = new Sequelize('flordeloto', 'root', '', {
    host: 'localhost',
    dialect: 'mysql',
    define: {
        timestamps: false, // evita columnas createdAt y updatedAt
    },
    logging: false // desactiva logs SQL en consola (opcional)
});

// --------------------------------------
// Exportar el objeto sequelize
// --------------------------------------
module.exports = sequelize;

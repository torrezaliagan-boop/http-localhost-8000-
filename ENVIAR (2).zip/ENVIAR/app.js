// ----------------------------
// app.js - Servidor principal
// ----------------------------

const express = require('express');
const app = express();
const path = require('path');
const cors = require('cors');

// ----------------------------
// Rutas
// ----------------------------
const arregloRuta = require('./routes/arregloRuta');
const clienteRuta = require('./routes/clienteRuta');
const empleadoRuta = require('./routes/empleadoRuta');
const pagoRuta = require('./routes/pagoRuta');
const pedidoRuta = require('./routes/pedidoRuta');
const proveedorRuta = require('./routes/proveedorRuta');


//LLAMAR LIBRERIAS
const jwt = require('jsonwebtoken');
 
//para acceder a la rutas
const authRuta= require('./routes/authRuta');

//express-session
const session = require('express-session');

// Configurar sesiones
app.use(session({
    secret: 'mi_secreto_super_seguro', // puedes cambiarlo
    resave: false,
    saveUninitialized: true
}));


// ----------------------------
// Configuración de CORS
// ----------------------------
const corsOptions = {
    origin: '*', // Permitir cualquier origen
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: true
};
app.use(cors(corsOptions));

// ----------------------------
// Middleware para formularios y JSON
// ----------------------------
app.use(express.urlencoded({ extended: true })); // necesario para datos de formularios
app.use(express.json()); // necesario para peticiones JSON

// ----------------------------
// Configuración de vistas (EJS)
// ----------------------------
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ----------------------------
// Carpeta pública (CSS, JS, imágenes)
// ----------------------------
app.use(express.static(path.join(__dirname, 'public')));

// ----------------------------
// Ruta principal (inicio)
// ----------------------------
app.get('/', (req, res) => {
    res.render('index'); // renderiza views/index.ejs
});
app.get('/principal', (req, res) => {
    res.render('vindex'); // renderiza views/index.ejs
});
app.get('/about', (req, res) => {
    res.render('about'); // renderiza views/index.ejs
});
app.get('/inicio', (req, res) => {
    res.render('vindex2'); // renderiza views/index.ejs
});
app.get('/shop', (req, res) => {
    res.render('vshop'); // renderiza views/index.ejs
});
app.get('/carrito', (req, res) => {
    res.render('vshop-detail'); // renderiza views/index.ejs
});
app.get('/service', (req, res) => {
    res.render('vservice'); // renderiza views/index.ejs
});
app.get('/contacto', (req, res) => {
    res.render('vmy-account'); // renderiza views/index.ejs
});
// -
// ----------------------------
// Rutas de la aplicación
// ----------------------------
app.use('/api/arreglo', arregloRuta);
app.use('/api/cliente', clienteRuta);
app.use('/api/empleado', empleadoRuta);
app.use('/api/pago', pagoRuta);
app.use('/api/pedido', pedidoRuta);
app.use('/api/proveedor', proveedorRuta);
// Levantar el servidor
// ----------------------------
const PORT = 8000;
app.listen(PORT, () => {
    console.log(`🚀 Servidor levantado en: http://localhost:${PORT}`);
});

//para usar rutas de usuario
app.use('/auth',authRuta);

app.use('/api/usuario', authRuta);
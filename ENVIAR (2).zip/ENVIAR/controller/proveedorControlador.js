const Proveedor = require('../models/proveedor');

exports.getTodosLosProveedores = async (req, res) => {
  try {
    const proveedores = await Proveedor.findAll();
    res.render('proveedor', { proveedor: proveedores });
  } catch (error) {
    console.error('Error al obtener los proveedores:', error);
    res.status(500).send('Error al obtener los proveedores');
  }
};

exports.mostrarFormularioNuevo = (req, res) => {
  res.render('nuevoProveedor');
};

exports.crearProveedor = async (req, res) => {
  const { nombre, ciudad, correo, telefono } = req.body;
  try {
    await Proveedor.create({ nombre, ciudad, correo, telefono });
    res.redirect('/api/proveedor');
  } catch (error) {
    console.error('Error al crear proveedor:', error);
    res.status(500).send('Error al crear proveedor');
  }
};

exports.getProveedorPorId = async (req, res) => {
  const { id_proveedor } = req.params;
  try {
    const proveedor = await Proveedor.findByPk(id_proveedor);
    if (!proveedor) return res.status(404).send('Proveedor no encontrado');
    res.render('nuevoProveedor', { proveedor });
  } catch (error) {
    console.error('Error al obtener proveedor:', error);
    res.status(500).send('Error al obtener proveedor');
  }
};

exports.actualizarProveedor = async (req, res) => {
  const { id_proveedor } = req.params;
  const { nombre, ciudad, correo, telefono } = req.body;
  try {
    await Proveedor.update({ nombre, ciudad, correo, telefono }, { where: { id_proveedor } });
    res.redirect('/api/proveedor');
  } catch (error) {
    console.error('Error al actualizar proveedor:', error);
    res.status(500).send('Error al actualizar proveedor');
  }
};

exports.eliminarProveedor = async (req, res) => {
  const { id_proveedor } = req.params;
  try {
    await Proveedor.destroy({ where: { id_proveedor } });
    res.redirect('/api/proveedor');
  } catch (error) {
    console.error('Error al eliminar proveedor:', error);
    res.status(500).send('Error al eliminar proveedor');
  }
};

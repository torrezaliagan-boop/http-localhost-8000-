const Pago = require('../models/pago');

// TRAER todos los pagos
exports.getTodosLosPagos = async (req, res) => {
    try {
        const pagos = await Pago.findAll();
        res.render('pago', { pago: pagos });
    } catch (error) {
        console.error('❌ Error al obtener pagos:', error);
        res.status(500).send(error);
    }
};

// MOSTRAR formulario para nuevo pago
exports.mostrarFormularioNuevo = (req, res) => {
    res.render('nuevopago', { pago: {} });
};

// CREAR pago
exports.crearPago = async (req, res) => {
    try {
        const { metodo, monto, fecha } = req.body;

        await Pago.create({ metodo, monto, fecha });

        res.redirect('/api/pago'); // redirige a la lista
    } catch (error) {
        console.error('❌ Error al crear pago:', error);
        res.status(500).send(error);
    }
};

// TRAER pago por ID para editar
exports.getPagoPorId = async (req, res) => {
    try {
        const { id_pago } = req.params;
        const pago = await Pago.findByPk(id_pago);

        if (pago) {
            res.render('nuevopago', { pago });
        } else {
            res.status(404).send({ mensaje: 'Pago no encontrado' });
        }
    } catch (error) {
        console.error('❌ Error al obtener pago por ID:', error);
        res.status(500).send(error);
    }
};

// ACTUALIZAR pago
exports.actualizarPago = async (req, res) => {
    try {
        const { id_pago } = req.params;
        const { metodo, monto, fecha } = req.body;

        const pago = await Pago.findByPk(id_pago);
        if (!pago) return res.status(404).json({ mensaje: 'Pago no encontrado' });

        await pago.update({ metodo, monto, fecha });

        res.redirect('/api/pago'); // redirige a la lista
    } catch (error) {
        console.error('❌ Error al actualizar pago:', error);
        res.status(500).send(error);
    }
};

// ELIMINAR pago
exports.eliminarPago = async (req, res) => {
    try {
        const { id_pago } = req.params;

        const eliminado = await Pago.destroy({ where: { id_pago } });

        if (eliminado) {
            res.redirect('/api/pago'); // redirige a la lista
        } else {
            res.status(404).json({ mensaje: 'Pago no encontrado' });
        }
    } catch (error) {
        console.error('❌ Error al eliminar pago:', error);
        res.status(500).send(error);
    }
};


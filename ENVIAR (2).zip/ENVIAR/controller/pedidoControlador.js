// -----------------------------
// llamado al modelo
// -----------------------------
const Pedido = require('../models/pedido');

// -----------------------------
// TRAER todos los pedidos
// -----------------------------
exports.getTodosLosPedidos = async (req, res) => {
    try {
        const pedidos = await Pedido.findAll();
        res.render('pedido', { pedido: pedidos });
    } catch (error) {
        console.error('Error al obtener los pedidos:', error);
        res.status(500).send(error);
    }
};

// -----------------------------
// MOSTRAR FORMULARIO para crear un nuevo pedido
// -----------------------------
exports.mostrarFormularioNuevo = (req, res) => {
    res.render('nuevopedido', { pedido: null }); // sin datos porque es creación
};

// -----------------------------
// CREAR un nuevo pedido
// -----------------------------
exports.crearPedido = async (req, res) => {
    try {
        const { fecha, total, estado, id_cliente } = req.body;
        await Pedido.create({ fecha, total, estado, id_cliente });
        res.redirect('/api/pedido'); // redirige a la lista
    } catch (error) {
        console.error('Error al crear el pedido:', error);
        res.status(500).send(error);
    }
};

// -----------------------------
// MOSTRAR FORMULARIO para editar un pedido por ID
// -----------------------------
exports.getPedidoPorId = async (req, res) => {
    try {
        const { id_pedido } = req.params;
        const pedido = await Pedido.findByPk(id_pedido);

        if (pedido) {
            res.render('nuevopedido', { pedido }); // usa la misma vista
        } else {
            res.status(404).send({ mensaje: 'Pedido no encontrado' });
        }
    } catch (error) {
        console.error('Error al obtener el pedido:', error);
        res.status(500).send(error);
    }
};

// -----------------------------
// ACTUALIZAR un pedido
// -----------------------------
exports.actualizarPedido = async (req, res) => {
    try {
        const { id_pedido } = req.params;
        const { fecha, total, estado, id_cliente } = req.body;

        const pedido = await Pedido.findByPk(id_pedido);
        if (!pedido) {
            return res.status(404).json({ mensaje: 'Pedido no encontrado' });
        }

        await pedido.update({ fecha, total, estado, id_cliente });
        res.redirect('/api/pedido');
    } catch (error) {
        console.error('Error al actualizar el pedido:', error);
        res.status(500).send(error);
    }
};

// -----------------------------
// ELIMINAR un pedido
// -----------------------------
exports.eliminarPedido = async (req, res) => {
    try {
        const { id_pedido } = req.params;
        const eliminado = await Pedido.destroy({
            where: { id_pedido }
        });

        if (eliminado) {
            res.redirect('/api/pedido');
        } else {
            res.status(404).json({ mensaje: 'Pedido no encontrado' });
        }
    } catch (error) {
        console.error('Error al eliminar el pedido:', error);
        res.status(500).send(error);
    }
};

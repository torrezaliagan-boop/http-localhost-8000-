// -----------------------------
// Importación de dependencias
// -----------------------------
const Cliente = require('../models/cliente');

// -----------------------------
// TRAER todos los clientes
// -----------------------------
exports.getTodosLosClientes = async (req, res) => {
    try {
        const clientes = await Cliente.findAll();
        res.render('cliente', { cliente: clientes }); // lista completa
    } catch (error) {
        console.error('❌ Error al obtener clientes:', error);
        res.status(500).send(error);
    }
};

// -----------------------------
// MOSTRAR formulario para nuevo cliente
// -----------------------------
exports.mostrarFormularioNuevo = (req, res) => {
    res.render('nuevocliente', { cliente: {} }); // siempre pasar un objeto vacío
};

// -----------------------------
// CREAR cliente
// -----------------------------
exports.crearCliente = async (req, res) => {
    try {
        const { nombre, telefono, correo, direccion } = req.body;

        await Cliente.create({
            nombre,
            telefono,
            correo,
            direccion
        });

        const clientes = await Cliente.findAll();
        res.render('cliente', { cliente: clientes });

    } catch (error) {
        console.error('❌ Error al crear cliente:', error);
        res.status(500).send(error);
    }
};

// -----------------------------
// TRAER cliente por ID para editar
// -----------------------------
exports.getClientePorId = async (req, res) => {
    try {
        const { id_cliente } = req.params;
        const cliente = await Cliente.findByPk(id_cliente);

        if (cliente) {
            res.render('nuevocliente', { cliente }); // reutiliza la misma vista
        } else {
            res.status(404).send({ mensaje: 'Cliente no encontrado' });
        }

    } catch (error) {
        console.error('❌ Error al obtener cliente por ID:', error);
        res.status(500).send(error);
    }
};

// -----------------------------
// ACTUALIZAR cliente
// -----------------------------
exports.actualizarCliente = async (req, res) => {
    try {
        const { id_cliente } = req.params;
        const { nombre, telefono, correo, direccion } = req.body;

        const cliente = await Cliente.findByPk(id_cliente);
        if (!cliente) {
            return res.status(404).json({ mensaje: 'Cliente no encontrado' });
        }

        await cliente.update({
            nombre,
            telefono,
            correo,
            direccion
        });

        const clientes = await Cliente.findAll();
        res.render('cliente', { cliente: clientes });

    } catch (error) {
        console.error('❌ Error al actualizar cliente:', error);
        res.status(500).send(error);
    }
};

// -----------------------------
// ELIMINAR cliente
// -----------------------------
exports.eliminarCliente = async (req, res) => {
    try {
        const { id_cliente } = req.params;

        const eliminado = await Cliente.destroy({
            where: { id_cliente }
        });

        if (eliminado) {
            const clientes = await Cliente.findAll();
            res.render('cliente', { cliente: clientes });
        } else {
            res.status(404).json({ mensaje: 'Cliente no encontrado' });
        }

    } catch (error) {
        console.error('❌ Error al eliminar cliente:', error);
        res.status(500).send(error);
    }
};



// Importar librerías
const Usuario = require('../models/usuario');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// --------------------- REGISTRAR USUARIO ---------------------
exports.registrarUsuario = async (req, res) => {
    try {
        const { nomusuario, email, contrasenia } = req.body;

        // Encriptar la contraseña
        const salt = await bcrypt.genSalt(10);
        const contraseniaEncriptada = await bcrypt.hash(contrasenia, salt);

        // Crear el nuevo usuario
        const usuario = await Usuario.create({ 
            nomusuario, 
            email, 
            contrasenia: contraseniaEncriptada 
        });

        // Obtener todos los usuarios para mostrar en la tabla
        const usuarios = await Usuario.findAll();
        res.render('usuario', { usuario: usuarios });

    } catch (error) {
        res.status(500).json({ mensaje: error.message });
    }
};

// --------------------- INICIAR SESIÓN ---------------------
exports.iniciarSesion = async (req, res) => {
    try {
        const { email, contrasenia } = req.body;

        const usuario = await Usuario.findOne({ where: { email } });
        if (!usuario) {
            return res.render('iniciarsesion', { message: 'Usuario inválido' });
        }

        const validarContrasenia = await bcrypt.compare(contrasenia, usuario.contrasenia);
        if (!validarContrasenia) {
            return res.render('iniciarsesion', { message: 'Contraseña inválida' });
        }

        const token = jwt.sign({ usuarioId: usuario.idusuario }, 'clave_secreta', { expiresIn: '5h' });

        // Aquí podrías guardar el token en sesión si lo deseas
        req.session.user = usuario;

        res.render('index', { message: 'Autenticado!!', user: req.session.user });

    } catch (error) {
        res.status(500).json({ message: 'No se puede iniciar sesión' });
    }
};

// --------------------- ELIMINAR USUARIO ---------------------
exports.eliminarUsuario = async (req, res) => {
    try {
        const { id } = req.params;

        await Usuario.destroy({ where: { idusuario: id } });

        const usuarios = await Usuario.findAll();
        res.render('usuario', { usuario: usuarios });

    } catch (error) {
        res.status(500).json({ mensaje: error.message });
    }
};


// --------------------- ACTUALIZAR USUARIO ---------------------
exports.editarUsuario = async (req, res) => {
    try {
        const { id } = req.params;
        const { nomusuario, email, contrasenia } = req.body;

        let datosActualizados = { nomusuario, email };

        if (contrasenia && contrasenia.trim() !== '') {
            const salt = await bcrypt.genSalt(10);
            datosActualizados.contrasenia = await bcrypt.hash(contrasenia, salt);
        }

        await Usuario.update(datosActualizados, { where: { idusuario: id } });

        const usuarios = await Usuario.findAll();
        res.render('usuario', { usuario: usuarios });

    } catch (error) {
        res.status(500).json({ mensaje: error.message });
    }
};



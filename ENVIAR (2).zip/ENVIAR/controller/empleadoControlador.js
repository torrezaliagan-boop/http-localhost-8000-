// -----------------------------
// controller/empleadoControlador.js
// -----------------------------

const Empleado = require('../models/empleado');

// -----------------------------
// TRAER todos los empleados
// -----------------------------
exports.getTodosLosEmpleados = async (req, res) => {
    try {
        const empleados = await Empleado.findAll();
        res.render('empleado', { empleado: empleados }); // lista completa
    } catch (error) {
        console.error('❌ Error al obtener empleados:', error);
        res.status(500).send(error);
    }
};

// -----------------------------
// MOSTRAR formulario para nuevo empleado
// -----------------------------
exports.mostrarFormularioNuevo = (req, res) => {
    res.render('nuevoempleado', { empleado: {} }); // objeto vacío
};

// -----------------------------
// CREAR empleado
// -----------------------------
exports.crearEmpleado = async (req, res) => {
    try {
        const { nombre, cargo, telefono } = req.body;

        await Empleado.create({
            nombre,
            cargo,
            telefono
        });

        // volver a la lista de empleados
        const empleados = await Empleado.findAll();
        res.render('empleado', { empleado: empleados });

    } catch (error) {
        console.error('❌ Error al crear empleado:', error);
        res.status(500).send(error);
    }
};

// -----------------------------
// TRAER empleado por ID para editar
// -----------------------------
exports.getEmpleadoPorId = async (req, res) => {
    try {
        const { id_empleado } = req.params;
        const empleado = await Empleado.findByPk(id_empleado);

        if (empleado) {
            res.render('nuevoempleado', { empleado }); // reutiliza la misma vista
        } else {
            res.status(404).send({ mensaje: 'Empleado no encontrado' });
        }

    } catch (error) {
        console.error('❌ Error al obtener empleado por ID:', error);
        res.status(500).send(error);
    }
};

// -----------------------------
// ACTUALIZAR empleado
// -----------------------------
exports.actualizarEmpleado = async (req, res) => {
    try {
        const { id_empleado } = req.params;
        const { nombre, cargo, telefono } = req.body;

        const empleado = await Empleado.findByPk(id_empleado);
        if (!empleado) {
            return res.status(404).json({ mensaje: 'Empleado no encontrado' });
        }

        await empleado.update({
            nombre,
            cargo,
            telefono
        });

        const empleados = await Empleado.findAll();
        res.render('empleado', { empleado: empleados });

    } catch (error) {
        console.error('❌ Error al actualizar empleado:', error);
        res.status(500).send(error);
    }
};

// -----------------------------
// ELIMINAR empleado
// -----------------------------
exports.eliminarEmpleado = async (req, res) => {
    try {
        const { id_empleado } = req.params;

        const eliminado = await Empleado.destroy({
            where: { id_empleado }
        });

        if (eliminado) {
            const empleados = await Empleado.findAll();
            res.render('empleado', { empleado: empleados });
        } else {
            res.status(404).json({ mensaje: 'Empleado no encontrado' });
        }

    } catch (error) {
        console.error('❌ Error al eliminar empleado:', error);
        res.status(500).send(error);
    }
};

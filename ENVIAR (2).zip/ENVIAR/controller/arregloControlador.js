// llamado al modelo
const Arreglo = require('../models/arreglo');

// TRAER todos los arreglos
exports.getTodosLosArreglos = async (req, res) => {
    try {
        const arreglos = await Arreglo.findAll();
        res.render('arreglo', { arreglo: arreglos });
    } catch (error) {
        console.error('Error al obtener los arreglos:', error);
        res.status(500).send(error);
    }
};

// MOSTRAR FORMULARIO para crear un nuevo arreglo
exports.mostrarFormularioNuevo = (req, res) => {
    res.render('nuevoarreglo', { arreglo: null }); // sin datos porque es creación
};

// CREAR un nuevo arreglo
exports.crearArreglo = async (req, res) => {
    try {
        const { nombre, tamaño, precio } = req.body;
        await Arreglo.create({ nombre, tamaño, precio });
        res.redirect('/api/arreglo'); // redirige a la lista
    } catch (error) {
        console.error('Error al crear el arreglo:', error);
        res.status(500).send(error);
    }
};

// MOSTRAR FORMULARIO para editar un arreglo por ID
exports.getArregloPorId = async (req, res) => {
    try {
        const { id_arreglo } = req.params;
        const arreglo = await Arreglo.findByPk(id_arreglo);

        if (arreglo) {
            res.render('nuevoarreglo', { arreglo }); // usa la misma vista
        } else {
            res.status(404).send({ mensaje: 'Arreglo no encontrado' });
        }
    } catch (error) {
        console.error('Error al obtener el arreglo:', error);
        res.status(500).send(error);
    }
};

// ACTUALIZAR un arreglo
exports.actualizarArreglo = async (req, res) => {
    try {
        const { id_arreglo } = req.params;
        const { nombre, tamaño, precio } = req.body;

        const arreglo = await Arreglo.findByPk(id_arreglo);
        if (!arreglo) {
            return res.status(404).json({ mensaje: 'Arreglo no encontrado' });
        }

        await arreglo.update({ nombre, tamaño, precio });
        res.redirect('/api/arreglo');
    } catch (error) {
        console.error('Error al actualizar el arreglo:', error);
        res.status(500).send(error);
    }
};

// ELIMINAR un arreglo
exports.eliminarArreglo = async (req, res) => {
    try {
        const { id_arreglo } = req.params;
        const eliminado = await Arreglo.destroy({
            where: { id_arreglo }
        });

        if (eliminado) {
            res.redirect('/api/arreglo');
        } else {
            res.status(404).json({ mensaje: 'Arreglo no encontrado' });
        }
    } catch (error) {
        console.error('Error al eliminar el arreglo:', error);
        res.status(500).send(error);
    }
};

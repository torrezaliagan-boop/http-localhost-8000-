// ----------------------------
// routes/pagoRuta.js
// ----------------------------

const express = require('express');
const router = express.Router();

// Llamado al controlador de pagos
const pagoControlador = require('../controller/pagoControlador');

// ============================
// Rutas para Pagos
// ============================

// ----------------------------
// Mostrar todos los pagos
// GET /api/pago
// ----------------------------
router.get('/', pagoControlador.getTodosLosPagos);

// ----------------------------
// Mostrar formulario para agregar un nuevo pago
// GET /api/pago/nuevo
// ----------------------------
router.get('/nuevo', pagoControlador.mostrarFormularioNuevo);

// ----------------------------
// Crear un nuevo pago
// POST /api/pago/crear
// ----------------------------
router.post('/crear', pagoControlador.crearPago);

// ----------------------------
// Mostrar un pago por ID para editar
// GET /api/pago/editar/:id_pago
// ----------------------------
router.get('/editar/:id_pago', pagoControlador.getPagoPorId);

// ----------------------------
// Actualizar un pago
// POST /api/pago/editar/:id_pago
// ----------------------------
router.post('/editar/:id_pago', pagoControlador.actualizarPago);

// ----------------------------
// Eliminar un pago
// GET /api/pago/eliminar/:id_pago
// ----------------------------
router.get('/eliminar/:id_pago', pagoControlador.eliminarPago);

// ============================
// Exportar router
// ============================
module.exports = router;

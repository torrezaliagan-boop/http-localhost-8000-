const express = require('express');
const router = express.Router();
const empleadoControlador = require('../controller/empleadoControlador');

router.get('/', empleadoControlador.getTodosLosEmpleados);
router.get('/nuevo', empleadoControlador.mostrarFormularioNuevo);
router.post('/crear', empleadoControlador.crearEmpleado);
router.get('/editar/:id_empleado', empleadoControlador.getEmpleadoPorId);
router.post('/editar/:id_empleado', empleadoControlador.actualizarEmpleado);
router.get('/eliminar/:id_empleado', empleadoControlador.eliminarEmpleado);

module.exports = router;

// ----------------------------
// routes/proveedorRuta.js
// ----------------------------

const express = require('express');
const router = express.Router();

// Llamado al controlador de proveedores
const proveedorControlador = require('../controller/proveedorControlador');

// ============================
// Rutas para Proveedores
// ============================

// ----------------------------
// Mostrar todos los proveedores
// GET /api/proveedor
// ----------------------------
router.get('/', proveedorControlador.getTodosLosProveedores);

// ----------------------------
// Mostrar formulario para agregar un nuevo proveedor
// GET /api/proveedor/nuevo
// ----------------------------
router.get('/nuevo', proveedorControlador.mostrarFormularioNuevo);

// ----------------------------
// Crear un nuevo proveedor
// POST /api/proveedor/crear
// ----------------------------
router.post('/crear', proveedorControlador.crearProveedor);

// ----------------------------
// Mostrar un proveedor por ID para editar
// GET /api/proveedor/editar/:id_proveedor
// ----------------------------
router.get('/editar/:id_proveedor', proveedorControlador.getProveedorPorId);

// ----------------------------
// Actualizar un proveedor
// POST /api/proveedor/editar/:id_proveedor
// ----------------------------
router.post('/editar/:id_proveedor', proveedorControlador.actualizarProveedor);

// ----------------------------
// Eliminar un proveedor
// GET /api/proveedor/eliminar/:id_proveedor
// ----------------------------
router.get('/eliminar/:id_proveedor', proveedorControlador.eliminarProveedor);

// ============================
// Exportar router
// ============================
module.exports = router;


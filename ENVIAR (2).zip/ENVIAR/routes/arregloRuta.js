// ----------------------------
// routes/arregloRuta.js
// ----------------------------

const express = require('express');
const router = express.Router();
const arregloControlador = require('../controller/arregloControlador');

// Definir las rutas en un arreglo
const rutasArreglo = [
    {
        metodo: 'get',
        path: '/',
        controlador: arregloControlador.getTodosLosArreglos
    },
    {
        metodo: 'get',
        path: '/nuevo',
        controlador: arregloControlador.mostrarFormularioNuevo
    },
    {
        metodo: 'post',
        path: '/crear',
        controlador: arregloControlador.crearArreglo
    },
    {
        metodo: 'get',
        path: '/editar/:id_arreglo',
        controlador: arregloControlador.getArregloPorId
    },
    {
        metodo: 'post',
        path: '/editar/:id_arreglo',
        controlador: arregloControlador.actualizarArreglo
    },
    {
        metodo: 'get',
        path: '/eliminar/:id_arreglo',
        controlador: arregloControlador.eliminarArreglo
    }
];

// Iterar sobre el arreglo para registrar las rutas
rutasArreglo.forEach(ruta => {
    router[ruta.metodo](ruta.path, ruta.controlador);
});

module.exports = router;

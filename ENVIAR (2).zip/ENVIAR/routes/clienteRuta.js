const express = require('express');
const router = express.Router();
const clienteControlador = require('../controller/clienteControlador');

// ----------------------------
// Rutas para Clientes
// ----------------------------

// Mostrar todos los clientes
router.get('/', clienteControlador.getTodosLosClientes);

// Mostrar formulario para nuevo cliente
router.get('/nuevo', clienteControlador.mostrarFormularioNuevo);

// Crear cliente
router.post('/crear', clienteControlador.crearCliente);

// Mostrar cliente por ID para editar
router.get('/editar/:id_cliente', clienteControlador.getClientePorId);

// Actualizar cliente
router.post('/editar/:id_cliente', clienteControlador.actualizarCliente);

// Eliminar cliente
router.get('/eliminar/:id_cliente', clienteControlador.eliminarCliente);

// ----------------------------
// Exportar router
// ----------------------------
module.exports = router;


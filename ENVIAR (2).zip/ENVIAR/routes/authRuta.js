// -------------------- RUTAS DE USUARIOS --------------------
const express = require('express');
const router = express.Router();
const authControlador = require('../controller/authControlador');
const Usuario = require('../models/usuario');

// -------------------- LISTAR TODOS LOS USUARIOS --------------------
router.get('/', async (req, res) => {
    const usuario = await Usuario.findAll();
    res.render('usuario', { usuario });
});

// -------------------- REGISTRO --------------------
router.post('/registro', authControlador.registrarUsuario);

// -------------------- INICIO DE SESIÓN --------------------
router.get('/iniciarsesion', (req, res) => {
    res.render('iniciarsesion');
});

router.post('/iniciarsesion', authControlador.iniciarSesion);

// -------------------- CERRAR SESIÓN --------------------
router.get('/cierre-sesion', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Error al cerrar sesión:', err);
            return res.status(500).send('Error al cerrar sesión');
        }
        res.clearCookie('connect.sid');
        res.redirect('/principal'); // Redirige a la página deseada
    });
});

// -------------------- ELIMINAR USUARIO --------------------
router.get('/eliminarusuario/:id', authControlador.eliminarUsuario);


// Guardar cambios del usuario editado
router.post('/editarusuario/:id', authControlador.editarUsuario);

module.exports = router;


// ----------------------------
// routes/pedidoRuta.js
// ----------------------------

const express = require('express');
const router = express.Router();
const pedidoControlador = require('../controller/pedidoControlador');

// Definir las rutas en un arreglo
const rutasPedido = [
    {
        metodo: 'get',
        path: '/',
        controlador: pedidoControlador.getTodosLosPedidos
    },
    {
        metodo: 'get',
        path: '/nuevo',
        controlador: pedidoControlador.mostrarFormularioNuevo
    },
    {
        metodo: 'post',
        path: '/crear',
        controlador: pedidoControlador.crearPedido
    },
    {
        metodo: 'get',
        path: '/editar/:id_pedido',
        controlador: pedidoControlador.getPedidoPorId
    },
    {
        metodo: 'post',
        path: '/editar/:id_pedido',
        controlador: pedidoControlador.actualizarPedido
    },
    {
        metodo: 'get',
        path: '/eliminar/:id_pedido',
        controlador: pedidoControlador.eliminarPedido
    }
];

// Iterar sobre el arreglo para registrar las rutas
rutasPedido.forEach(ruta => {
    router[ruta.metodo](ruta.path, ruta.controlador);
});

module.exports = router;

// llamado de librerías
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

// definimos el modelo de la tabla 'arreglo'
const Arreglo = sequelize.define('Arreglo', { // Usa mayúscula inicial por convención
    id_arreglo: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true, // ✅ genera automáticamente el ID
        allowNull: false     // 🔹 asegura que no sea nulo
    },
    nombre: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    tamaño: {
        type: DataTypes.STRING(20),
        allowNull: false
    },
    precio: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    }
}, {
    tableName: 'arreglo',  // nombre exacto de la tabla en la BD
    timestamps: false,     // no agrega createdAt / updatedAt
    freezeTableName: true  // evita que Sequelize pluralice el nombre
});

module.exports = Arreglo;

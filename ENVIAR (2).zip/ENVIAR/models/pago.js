// -----------------------------
// Llamado de librerías
// -----------------------------
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

// -----------------------------
// Definición del modelo 'pago'
// -----------------------------
const Pago = sequelize.define('pago', {
    id_pago: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    metodo: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    monto: {
        type: DataTypes.FLOAT,
        allowNull: true
    },
    fecha: {
        type: DataTypes.DATE,
        allowNull: true
    }
}, {
    tableName: 'pago',  // nombre de la tabla en la base de datos
    timestamps: false   // evita que Sequelize cree createdAt y updatedAt
});

// -----------------------------
// Exportar modelo
// -----------------------------
module.exports = Pago;

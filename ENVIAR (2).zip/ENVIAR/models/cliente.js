// -----------------------------
// Llamado de librerías
// -----------------------------
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

// -----------------------------
// Definición del modelo 'cliente'
// -----------------------------
const Cliente = sequelize.define('cliente', {
    id_cliente: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    nombre: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    telefono: {
        type: DataTypes.STRING(20),
        allowNull: true
    },
    correo: {
        type: DataTypes.STRING(150),
        allowNull: true
    },
    direccion: {
        type: DataTypes.STRING(150),
        allowNull: true
    }
}, {
    tableName: 'cliente',  // nombre de la tabla en la base de datos
    timestamps: false      // evita que Sequelize cree createdAt y updatedAt
});

// -----------------------------
// Exportar modelo
// -----------------------------
module.exports = Cliente;

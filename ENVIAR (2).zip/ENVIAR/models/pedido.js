// -----------------------------
// Llamado de librerías
// -----------------------------
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

// -----------------------------
// Definición del modelo 'pedido'
// -----------------------------
const Pedido = sequelize.define('pedido', {
    id_pedido: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    fecha: {
        type: DataTypes.DATE,
        allowNull: true
    },
    total: {
        type: DataTypes.FLOAT,
        allowNull: true
    },
    estado: {
        type: DataTypes.STRING(50),
        allowNull: true
    },
    id_cliente: {
        type: DataTypes.INTEGER,
        allowNull: true
        // Si quieres relacionarlo con la tabla cliente:
        // references: { model: 'cliente', key: 'id_cliente' }
    }
}, {
    tableName: 'pedido',  // nombre de la tabla en la base de datos
    timestamps: false     // evita que Sequelize cree createdAt y updatedAt
});

// -----------------------------
// Exportar modelo
// -----------------------------
module.exports = Pedido;

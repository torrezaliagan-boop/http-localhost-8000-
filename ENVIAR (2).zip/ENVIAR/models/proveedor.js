// -----------------------------
// models/proveedor.js
// -----------------------------

const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

// Definición del modelo 'proveedor'
const Proveedor = sequelize.define('proveedor', {
    id_proveedor: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    nombre: {
        type: DataTypes.STRING(100),
        allowNull: false
    },
    ciudad: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    correo: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    telefono: {
        type: DataTypes.STRING(50),
        allowNull: true
    }
}, {
    tableName: 'proveedor',  // nombre de la tabla en la base de datos
    timestamps: false         // evita que Sequelize cree createdAt y updatedAt
});

module.exports = Proveedor;

// Llamado de librerías
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
 
// Definimos el modelo del usuario 'usuario', nombre de la tabla en la BDD
const Usuario = sequelize.define('usuario', {
    idusuario: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    nomusuario: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    contrasenia: {
        type: DataTypes.STRING,
        allowNull: false
    }
},{
    tableName: 'usuario', // nombre de la tabla en la BD
    timestamps: false       // evita crear columnas createdAt y updatedAt
});
 
// Exportamos el modelo
module.exports = Usuario;


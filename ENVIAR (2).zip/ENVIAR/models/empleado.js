// -----------------------------
// Llamado de librerías
// -----------------------------
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

// -----------------------------
// Definición del modelo 'empleado'
// -----------------------------
const Empleado = sequelize.define('empleado', {
    id_empleado: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    nombre: {
        type: DataTypes.STRING(100),
        allowNull: true
    },
    cargo: {
        type: DataTypes.STRING(50),
        allowNull: true
    },
    telefono: {
        type: DataTypes.STRING(20),
        allowNull: true
    }
}, {
    tableName: 'empleado',  // nombre de la tabla en la base de datos
    timestamps: false       // evita que Sequelize cree createdAt y updatedAt
});

// -----------------------------
// Exportar modelo
// -----------------------------
module.exports = Empleado;
